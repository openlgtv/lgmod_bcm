#!/bin/sh

temp=0
k=0
MAX=416
NODE=sda

while [ $k -lt $MAX ] ; do
	if [ $k -ge 0 -a $k -le 6 ] ; then
		NODE=sda
	fi
	if [ $k -ge 16 -a $k -le 22 ] ; then
		NODE=sdb
	fi
	if [ $k -ge 32 -a $k -le 38 ] ; then
		NODE=sdc
	fi
	if [ $k -ge 48 -a $k -le 54 ] ; then
		NODE=sdd
	fi
	if [ $k -ge 64 -a $k -le 70 ] ; then
		NODE=sde
	fi
	if [ $k -ge 80 -a $k -le 86 ] ; then
		NODE=sdf
	fi
	if [ $k -ge 96 -a $k -le 102 ] ; then
		NODE=sdg
	fi
	if [ $k -ge 112 -a $k -le 118 ] ; then
		NODE=sdh
	fi
	if [ $k -ge 128 -a $k -le 134 ] ; then
		NODE=sdi
	fi
	if [ $k -ge 144 -a $k -le 150 ] ; then
		NODE=sdj
	fi
	if [ $k -ge 160 -a $k -le 166 ] ; then
		NODE=sdk
	fi
	if [ $k -ge 176 -a $k -le 182 ] ; then
		NODE=sdl
	fi
	if [ $k -ge 192 -a $k -le 198 ] ; then
		NODE=sdm
	fi
	if [ $k -ge 208 -a $k -le 214 ] ; then
		NODE=sdn
	fi
	if [ $k -ge 224 -a $k -le 230 ] ; then
		NODE=sdo
	fi
	if [ $k -ge 240 -a $k -le 246 ] ; then
		NODE=sdp
	fi
	if [ $k -ge 256 -a $k -le 262 ] ; then
		NODE=sdq
	fi
	if [ $k -ge 272 -a $k -le 278 ] ; then
		NODE=sdr
	fi
	if [ $k -ge 288 -a $k -le 294 ] ; then
		NODE=sds
	fi
	if [ $k -ge 304 -a $k -le 310 ] ; then
		NODE=sdt
	fi
	if [ $k -ge 320 -a $k -le 326 ] ; then
		NODE=sdu
	fi
	if [ $k -ge 336 -a $k -le 342 ] ; then
		NODE=sdv
	fi
	if [ $k -ge 352 -a $k -le 358 ] ; then
		NODE=sdw
	fi
	if [ $k -ge 368 -a $k -le 374 ] ; then
		NODE=sdx
	fi
	if [ $k -ge 384 -a $k -le 390 ] ; then
		NODE=sdy
	fi
	if [ $k -ge 400 -a $k -le 406 ] ; then
		NODE=sdz
	fi

	temp=`expr $k % 16 + 1`
	if [ $temp -eq 1 ]
	then
		mknod $NODE b 8 $k
		#mknod $NODE b 8 $k &> /dev/null
	else
		mknod $NODE`expr $temp - 1` b 8 $k
		#mknod $NODE`expr $temp - 1` b 8 $k &> /dev/null
	fi

	k=`expr $k + 1`
done
